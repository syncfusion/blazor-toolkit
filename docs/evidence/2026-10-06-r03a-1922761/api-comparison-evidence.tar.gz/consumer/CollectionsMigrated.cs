using System.Collections.Generic;
using Syncfusion.Blazor.Toolkit.Popups;

public static class DialogConsumer
{
    public static IList<DialogButton>? ReadButtons(SfDialog dialog) => dialog.GetButtonItems();
}
