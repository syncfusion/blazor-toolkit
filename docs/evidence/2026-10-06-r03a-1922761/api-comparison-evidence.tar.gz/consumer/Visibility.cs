using System;
using Syncfusion.Blazor.Toolkit.Charts;

public static class RendererConsumer
{
    public static Type RendererType => typeof(ChartRenderer);
}
