using Syncfusion.Blazor.Toolkit.Data;

public sealed class ConsumerAdaptor<T> : DataAdaptor<T> where T : notnull
{
}
