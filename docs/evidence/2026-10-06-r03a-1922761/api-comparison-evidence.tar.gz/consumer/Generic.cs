using Syncfusion.Blazor.Toolkit.Data;

// A valid 1.0.2 consumer must not silently acquire new diagnostics on rebuild.
public sealed class ConsumerAdaptor<T> : DataAdaptor<T>
{
}
