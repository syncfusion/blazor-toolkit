using System.Collections.Generic;
using Syncfusion.Blazor.Toolkit.Popups;

public static class DialogConsumer
{
    public static List<DialogButton>? ReadButtons(SfDialog dialog) => dialog.GetButtonItems();
}
